# Tethys IM Web

IM Web 测试客户端，用于快速测试 IM Server 服务相关的功能。

## 功能
* [x] 快速连接
* [x] 私聊
* [ ] 群聊
* [ ] 本地配置存储
* [ ] 本地消息存储

## 相关项目
* [Vue3](https://v3.vuejs.org/)
* [Bulma](https://bulma.io/)